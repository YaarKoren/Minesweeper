import './App.css';
import Board from './components/Board';
import './styles.css';

export default function App() {
  return (
    <>
    <h1>Welcome to minesweeper!</h1>
    <Board></Board>
    </>
  );

}