import '../styles.css';
import Square from './Square';
import { buildBoard } from '../utils/buildBoard';
import { useState, useEffect } from 'react';

export default function Board() {

const test = "test"
const n = 9;
const m = 9;
const minesNum = 10;
    
const [board, setBoard] = useState(buildBoard(n, m, minesNum));

function onLeftClick(x, y){
   
}

function onRightClick(e, x, y) {
    e.preventDefault();
    setBoard((prevBoard) => {
      const newBoard = prevBoard.map((row) => [...row]); // Create a shallow copy of the board
  
      if (prevBoard[x][y].isFlagged) {
        // If there's a flag already, remove the flag
        newBoard[x][y] = { ...newBoard[x][y], isFlagged: false, content: "" };
      } else if (!prevBoard[x][y].isRevealed) {
        // No flag, and not revealed yet -> put flag
        newBoard[x][y] = { ...newBoard[x][y], isFlagged: true, content: "🚩" };
      }
  
      return newBoard;
    });
  }

return (
    <main>
       {board.map((row, rowIndex) => (
            <div className='board-row' key={rowIndex}>
            {row.map((item, itemIndex) => (
             <button
                key={`${item.x}-${item.y}`}
                className='square'
                onContextMenu={(e) => onRightClick(e, item.x, item.y)}
                onClick={() => onLeftClick(item.x, item.y)}
                >
                {item.content}
             </button>
            ))}
            </div>
        ))}
    </main>
);


    
}